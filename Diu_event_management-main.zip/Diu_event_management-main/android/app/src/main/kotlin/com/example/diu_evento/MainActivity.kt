package com.example.diu_evento

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
